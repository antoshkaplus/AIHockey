/**
 * Created by antoshkaplus on 9/20/14.
 */
public interface AIRole {
    public AIMove move();
}
